<?php
function getsites(){
    return array('a', 'e', 'i', 'o', 'u'); //site names
}

function checkSites(){
    $array_sites = getsites();
    // Get the ip
    $arg = $_SERVER["HTTP_REFERER"];

    // Check if we have a command line parameter
    if (!isset($arg) || $arg == "") {
        die("");
    }

    //default response
    $site_response = false;

    //Site allow
    foreach ($array_sites as $site) {
        if (strpos($arg, $site) !== false)
            $site_response = true;
    }

    return $site_response;
}

//retorna lista de sites
if(isset($_GET['get']))
    echo json_encode(getsites());