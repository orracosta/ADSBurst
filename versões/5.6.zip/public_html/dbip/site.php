<?php
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');

require_once "sitelist.php";

if (checkSites() == true) {
    $response = array('valid' => 'true');
}else{
    die("");
}

//return json
echo json_encode($response);