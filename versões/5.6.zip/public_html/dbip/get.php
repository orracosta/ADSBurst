<?php
// Include the DB-IP class
require "dbip.class.php";

function dbip_check($arg){
    try{
        // Check if we have a command line parameter
        if (!isset($arg) || $arg == "") {
            die("Você precisa informar um IP!");
        }

        $db = new PDO("mysql:host=localhost;dbname=iplezier", "site", "guerejo");

        // Instanciate a new DBIP object with the database connection
        $dbip = new DBIP($db);

        // Lookup an IP address
        $inf = $dbip->Lookup($arg);

        //Add the requested ID to Json
        $inf->ip = $arg;

        //Config
        $array_isp = array('google', 'hostdime', 'ovh hosting', 'facebook', 'youtube', 'verizon'); //isp names
        $array_country = array('BR', 'PT');    //country allow

        //default response
        $response = array('valid' => 'false');
        $country_response = false;
        $isp_response = true;

        //ISP block
        foreach ($array_isp as $isp) {
            if (strpos(strtolower($inf->isp_name), $isp) !== false || strpos(strtolower($inf->organization_name), $isp) !== false)
                $isp_response = false;
        }

        //Contry Allow
        //#comentado temporariamente
        foreach ($array_country as $country) {
            if (strpos($inf->country, $country) !== false)
                $country_response = true;
        }

        //Do all verifications
        if ($country_response == true && $isp_response == true) {
            $response = array('valid' => 'true');
        }

        //return json
        return json_encode($response);
    } catch (DBIP_Exception $e) {
        echo "error: {$e->getMessage()}\n";
    }
}