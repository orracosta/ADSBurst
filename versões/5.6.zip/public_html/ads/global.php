<?php
//error_reporting(0);	
function connect_db() {	
    try{
        $pdo=new PDO("mysql:host=localhost;dbname=iplezier","site","guerejo");
    }
    catch(PDOException $e){
        die($e->getCode());
    }

    return $pdo;
}


function getIP(){
    if(isset($_SERVER['HTTP_CF_CONNECTING_IP']))
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    else if(isset($_SERVER['HTTP_X_SUCURI_CLIENTIP']))
        return $_SERVER['HTTP_X_SUCURI_CLIENTIP'];
    else
        return $_SERVER['REMOTE_ADDR'];
}