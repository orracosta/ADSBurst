var random = Math.floor(Math.random() * (30 - 15 + 1) + 15);
var delay = random + '' + 500;
URL = "https://www.mania.gg/?utm_ads=parceiros";

function urlupdate(param1, param2, param3){
    history.replaceState(param1, param2, param3);
}

function setjs(param1){
	$.getJSON('https://www.mania.gg/set/session/' + param1, function(data) {});
}