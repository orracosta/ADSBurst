<?php
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');

require "../../dbip/sitelist.php";
require "../global.php";

if (checkSites() != true)
	die("");

$pdo = connect_db();

$stmt = $pdo->prepare('SELECT timeclick FROM iplezier WHERE ipclick = :ipclick AND tipo = :tipo ORDER BY timeclick DESC LIMIT 1');
$stmt->bindValue(':ipclick', getIP());
$stmt->bindParam(":tipo", $_GET['tipo']);
$stmt->execute();

$get = $stmt->fetch(PDO::FETCH_ASSOC);

if($get['timeclick'] == null)
	$get['timeclick'] = "0";

$response = array('timeclick' => $get['timeclick']);
header('Content-Type: text/javascript; charset=UTF-8');
echo json_encode($response);