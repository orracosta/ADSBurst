<?php
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');


require "../dbip/sitelist.php";
require "../dbip/get.php";
require "global.php";


//verifica se o site é válido
if (checkSites() != true) {
    die("");
}

//check ip
$acesso = json_decode(dbip_check(getIP()));
function Encrypt($s1, $id = 1745) {
    $i=null; $x=0; $x2=null; $x3=null; $x4=rand(0,25); $sx='';
    $result = chr($x4+65);
    $x4 = $x4 + $id;
    for ($i = 0; $i <= strlen($s1)-1; $i++) {
        $x = ord(@$s1[$i]) + @$x4;
        if ($x <= 25) {
            $sx = 'A' . chr($x+65);
        } else {
            $x2 = floor( $x / 25 );
            $x3 = $x - ($x2 * 25);
            $sx = chr($x2+65) . chr($x3+65);
        }
        $result = $result . $sx;
    }
    return base64_encode($result);
}


if($acesso->valid == "true"){
    if (isset($_GET['file']) && !empty($_GET['file'])) {
        $file = $_GET['file'];
    } else {
        die("");
    }

    //CSS
    if ($file == "bootstrap.min"){
        header('Content-Type: text/css; charset=UTF-8');
        $file = "inc/iplezier.css";
    }

    //DECRIPT JS
    //---------------
    else if (!(strpos($file, 'cript/') !== false)){
        header('Content-Type: text/javascript; charset=UTF-8');
        //echo "var requestJS = '$file';";
        //echo file_get_contents("../ads/inc/cript.js");
    }

    //CRIPT
    //---------------
    //crazzy
    else if ($file == "cript/crazzy/jquery.min"){
        header('Content-Type: text/javascript; charset=UTF-8');
        //echo Encrypt(file_get_contents("../ads/inc/crazzyJS.js"));
    }
    //megafilmes
    else if ($file == "cript/mega/jquery.min"){
        header('Content-Type: text/javascript; charset=UTF-8');
        //echo Encrypt(file_get_contents("../ads/inc/megafilmesJS.js"));
    }
    //redecanais
    else if ($file == "cript/rcplayer/jquery.min"){
        header('Content-Type: text/javascript; charset=UTF-8');
        //echo Encrypt(file_get_contents("../ads/inc/redecanaisJS.js"));
    }
    //player
    else if ($file == "cript/player/jquery.min"){
        header('Content-Type: text/javascript; charset=UTF-8');
        //echo Encrypt(file_get_contents("../ads/inc/playerJS.js"));
    }
    else{
        die("");
    }

    if (file_exists("../ads/".$file)) {
        echo file_get_contents("../ads/".$file);
        return;
    }
}