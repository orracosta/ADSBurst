<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="pt-br">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?=base_url('assets/css/bootstrap.min.css');?>">
    <link rel="stylesheet" href="<?=base_url('assets/css/site.css?3');?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css"
          integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">
    <link rel="apple-touch-icon" sizes="57x57" href="<?=base_url('assets/img/icones/apple-icon-57x57.png')?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?=base_url('assets/img/icones/apple-icon-60x60.png')?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?=base_url('assets/img/icones/apple-icon-72x72.png')?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?=base_url('assets/img/icones/apple-icon-76x76.png')?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?=base_url('assets/img/icones/apple-icon-114x114.png')?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?=base_url('assets/img/icones/apple-icon-120x120.png')?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?=base_url('assets/img/icones/apple-icon-144x144.png')?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?=base_url('assets/img/icones/apple-icon-152x152.png')?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?=base_url('assets/img/icones/apple-icon-180x180.png')?>">
    <link rel="icon" type="image/png" sizes="192x192" href="<?=base_url('assets/img/icones/android-icon-192x192.png')?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?=base_url('assets/img/icones/favicon-32x32.png')?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?=base_url('assets/img/icones/favicon-96x96.png')?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?=base_url('assets/img/icones/favicon-16x16.png')?>">

    <title><?=$titulo?></title>
	<meta name="keywords" content="curiosidades, tecnologia, historia, fatos" />
	<meta name="description" content="As maiores curiosidades do mundo, todas as dúvidas que você teve um dia enfim solucionadas, a curiosidade só matou o gato porque ele não sabia onde procurar!" />
	<meta property="og:locale" content="pt_BR" />
	<meta property="og:type" content="website" />
	<meta property="og:description" content="Mania - As maiores curiosidades do mundo, todas as dúvidas que você teve um dia enfim solucionadas, a curiosidade só matou o gato porque ele não sabia onde procurar!" />
</head>
<body>
<header class="header">
    <div class="container">
        <div class="row mainrow">
            <div class="col align-self-center col-lg-6 col-md-12 col-12 text-center">
                <img class="img-fluid" src="https://cdn.rawgit.com/izinezion/site-news/5d5058bd/logo.png" alt="Mania"/>
            </div>
            <div class="offset-lg-2 search-box col align-self-center col-lg-4 col-md-12 col-12">
                <input class="form-control mr-sm-2" type="search" placeholder="Pesquisar..."
                       aria-label="Search">
                <i class="fas fa-search position-absolute"></i>
            </div>
        </div>
    </div>
</header>