<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<hr>
<center>© 2018 - Mania - Todas as imagens de filmes, séries e etc são marcas registradas de seus respectivos proprietários.</center>
</div>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?=base_url('assets/js/jquery-3.3.1.slim.min.js'); ?>"></script>
<script src="<?=base_url('assets/js/popper.min.js'); ?>"></script>
<script src="<?=base_url('assets/js/bootstrap.min.js'); ?>"></script>
</body>
</html>