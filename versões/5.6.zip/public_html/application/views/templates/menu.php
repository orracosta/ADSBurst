<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container text-center">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01"
                aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarColor01">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?=base_url();?>">Principal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?=base_url("noticias");?>">Notícias</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?=base_url("mais-lidas");?>">10 Mais Lidas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?=base_url("privacidade");?>">Privacidade</a>
                </li>
            </ul>
        </div>
    </div>
</nav>