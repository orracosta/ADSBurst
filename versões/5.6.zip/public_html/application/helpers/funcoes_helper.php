<?php
defined('BASEPATH') OR exit('No direct script access allowed');

function site_ads()
{
    $site_ads = "redecanais";
    if (strpos($_SERVER['HTTP_HOST'], "mania.gg") !== false)
        $site_ads = "crazzy";
    elseif (strpos($_SERVER['HTTP_HOST'], "imania.pw") !== false)
        $site_ads = "redecanais";
    elseif (strpos($_SERVER['HTTP_HOST'], "onmania.pw") !== false)
        $site_ads = "player";

    return $site_ads;
}

function site_als()
{
    $site_ads = "UA-114714565-1";
    if (strpos($_SERVER['HTTP_HOST'], "mania.gg") !== false)
        $site_ads = "UA-114714565-1";
    elseif (strpos($_SERVER['HTTP_HOST'], "imania.pw") !== false)
        $site_ads = "UA-119189173-1";
    elseif (strpos($_SERVER['HTTP_HOST'], "onmania.pw") !== false)
        $site_ads = "UA-119893765-1";

    return $site_ads;
}

//Limpador de URL para fins de SEO
function limpar($string, $slug = false) {
    $string = strtolower($string);
    // Código ASCII das vogais
    $ascii['a'] = range(224, 230);
    $ascii['e'] = range(232, 235);
    $ascii['i'] = range(236, 239);
    $ascii['o'] = array_merge(range(242, 246), array(240, 248));
    $ascii['u'] = range(249, 252);
    // Código ASCII dos outros caracteres
    $ascii['b'] = array(223);
    $ascii['c'] = array(231);
    $ascii['d'] = array(208);
    $ascii['n'] = array(241);
    $ascii['y'] = array(253, 255);
    foreach ($ascii as $key=>$item) {
        $acentos = '';
        foreach ($item AS $codigo) $acentos .= chr($codigo);
        $troca[$key] = '/['.$acentos.']/i';
    }
    $string = preg_replace(array_values($troca), array_keys($troca), $string);
    // Slug?
    if ($slug) {
        // Troca tudo que não for letra ou número por um caractere ($slug)
        $string = preg_replace('/[^a-z0-9]/i', $slug, $string);
        // Tira os caracteres ($slug) repetidos
        $string = preg_replace('/' . $slug . '{2,}/i', $slug, $string);
        $string = trim($string, $slug);
    }
    return $string;
}

//Verifica se foi recebido em JSON
function jreturn($response, $json)
{
    //Retorna em formato JSON
    if ($json == 1)
        echo json_encode($response);
    //Retorna em formato PHP
    else
        return $response;
}

//Caso tenha a variavel do cloudflare, utiliza ela para o IP
function cloudflareip()
{
        return $_SERVER['REMOTE_ADDR'];
}

//get content
function get_content($url)
{
    $ch = @curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $page = curl_exec($ch);
    curl_close($ch);
    return $page;
}